﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Stutdent_Complain_Management.App_Start
{
    public class IdentityConfig
    {
    }
}