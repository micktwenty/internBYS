﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Complains_System.Constants
{
    public class SystemConstants
    {
        public const string MainConnectionString = "ComplainsConn";

        
    }
}
