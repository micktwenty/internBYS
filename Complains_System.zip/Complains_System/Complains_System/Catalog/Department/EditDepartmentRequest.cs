﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Complains_System.Catalog.Department
{
    public class EditDepartmentRequest
    {
        public int id { get; set; }
        public string name { get; set; }
    }
}
